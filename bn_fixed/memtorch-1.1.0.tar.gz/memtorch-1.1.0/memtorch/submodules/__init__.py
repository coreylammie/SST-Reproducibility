import importlib
importlib.import_module('.pytorch-playground', 'memtorch.submodules')
